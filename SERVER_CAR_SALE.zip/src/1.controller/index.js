const ControllerUser = require("./user");
const ControllerAuth = require("./auth");
const ControllerProduk = require("./produk");
const ControllerAdmin = require("./admin");

module.exports = {
  ControllerUser,
  ControllerAuth,
  ControllerProduk,
  ControllerAdmin,
};
