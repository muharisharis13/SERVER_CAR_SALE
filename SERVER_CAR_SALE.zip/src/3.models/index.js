const { user } = require("./user");
const { produk } = require("./produk");

module.exports = { user, produk };
