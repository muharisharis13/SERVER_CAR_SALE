exports.pathViewImage = (route, text) =>
  `${process.env.BASE_URL}${route}/${text}`;
