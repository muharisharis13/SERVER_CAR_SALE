const ControllerUser = require("./user");
const ControllerAuth = require("./auth")

module.exports = {
  ControllerUser,
  ControllerAuth
};
