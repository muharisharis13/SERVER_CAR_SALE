const ControllerUser = require("./user");
const ControllerAuth = require("./auth")
const ControllerProduk = require("./produk")

module.exports = {
  ControllerUser,
  ControllerAuth,
  ControllerProduk
};
