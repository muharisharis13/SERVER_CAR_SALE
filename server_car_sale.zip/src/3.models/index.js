const { user } = require("./user");
const { produk } = require("./produk");
const  preSales  = require("./preSales");
const  status  = require("./status");

module.exports = { user, produk, preSales, status };
