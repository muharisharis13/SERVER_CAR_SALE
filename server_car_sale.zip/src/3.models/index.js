const { user } = require("./user");
const { produk } = require("./produk");
const preSales = require("./preSales");

module.exports = { user, produk, preSales };
